package com.universalapp.sankalp.learningapp.controller.membershipPlan;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.api.RestClient;
import com.universalapp.sankalp.learningapp.controller.selection.SubjectListSelectorAdapter;
import com.universalapp.sankalp.learningapp.controller.subject.SubjectListAdapter;
import com.universalapp.sankalp.learningapp.customLoader.LoaderDialog;
import com.universalapp.sankalp.learningapp.model.membershipPack.MembershipDetail;
import com.universalapp.sankalp.learningapp.model.subject.SubjectResponse;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.CustomDialog;
import com.universalapp.sankalp.learningapp.view.activities.HomeActivity;
import com.universalapp.sankalp.learningapp.view.activities.SubChapterActivity;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MebershipPlanListAdapter  extends RecyclerView.Adapter<MebershipPlanListAdapter.MyViewHolder> {

    List<MembershipDetail> arrayListMembershipPlan = new ArrayList<>();
    Activity activity;

    public MebershipPlanListAdapter (Activity activity, List<MembershipDetail> arrayListChapter){
        this.activity = activity;
        this.arrayListMembershipPlan = arrayListChapter;
    }

    @NonNull
    @Override
    public MebershipPlanListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        return new MebershipPlanListAdapter.MyViewHolder(LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_membership_layout, viewGroup, false));

    }

    @Override
    public void onBindViewHolder(@NonNull MebershipPlanListAdapter.MyViewHolder viewHolder, int position) {

        //viewHolder.textViewName.setText(arrayListTimeSlot.get(i).getName());
        viewHolder.textViewPlanName.setText(arrayListMembershipPlan.get(position).getPlanName());
        viewHolder.textViewPlanPrice.setText(arrayListMembershipPlan.get(position).getPrice()+" Rs");
        viewHolder.textViewPlanValidiy.setText(arrayListMembershipPlan.get(position).getValidity() +" "+arrayListMembershipPlan.get(position).getValidityType());
        //viewHolder.textViewPlanName.setText(arrayListMembershipPlan.get(position).getPlanName());

        viewHolder.linearLayoutPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (arrayListMembershipPlan.get(position).getAccessLevel()){
                    case "s":

                        if(Integer.parseInt(arrayListMembershipPlan.get(position).getTotal()) > 0){

                            showSubjectPopup(Integer.parseInt(arrayListMembershipPlan.get(position).getTotal()));

                        }else{

                        }
                        break;

                    case "c":

                        break;
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        //return arrayListTimeSlot.size();
        return arrayListMembershipPlan.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{



        @BindView(R.id.text_membership_plan_name)
        TextView textViewPlanName;
        @BindView(R.id.text_membership_plan_price)
        TextView textViewPlanPrice;
        @BindView(R.id.text_membership_plan_validiy)
        TextView textViewPlanValidiy;
        @BindView(R.id.layout_plan)
        LinearLayout linearLayoutPlan;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            ButterKnife.bind(this,itemView);

        }
    }

    public  void updateList(List<MembershipDetail> arrayListMembershipPlan){
        this.arrayListMembershipPlan = arrayListMembershipPlan;
        notifyDataSetChanged();
    }


    private void showSubjectPopup(int numberOfSelection){

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.popup_subject_selection);

        TextView tvTitle =  dialog.findViewById(R.id.tv_title);
        TextView tvCancel =  dialog.findViewById(R.id.tv_cancel);
        TextView tvSubmit =  dialog.findViewById(R.id.tv_submit);
        RecyclerView recyclerViewSubjectList =  dialog.findViewById(R.id.recycler_subject_list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(activity);
        recyclerViewSubjectList.setLayoutManager(layoutManager);

        getSubjectList(recyclerViewSubjectList, numberOfSelection);
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });
        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



            }
        });

        dialog.show();
    }

    private void getSubjectList(RecyclerView recyclerViewSubject, int numberOfSelection){

        LoaderDialog dialog = new LoaderDialog(activity);
        dialog.showProgress();

        String params = Constants.USER_DETAILS.getUserId();
        Call<SubjectResponse> request = RestClient.getInstance(activity).getSubject(params);

        request.enqueue(new Callback<SubjectResponse>() {
            @Override
            public void onResponse(Call<SubjectResponse> call, Response<SubjectResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(LoginActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){

                    SubjectListSelectorAdapter adapter = new SubjectListSelectorAdapter(activity, response.body().getSubject(), numberOfSelection);
                    recyclerViewSubject.setAdapter(adapter);

                }else{
                    CustomDialog.commonDialog(activity, "Login fail", "Credential mismatch.", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<SubjectResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });

    }
}