package com.universalapp.sankalp.learningapp.view.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.api.RestClient;
import com.universalapp.sankalp.learningapp.controller.chapter.ChapterListAdapter;
import com.universalapp.sankalp.learningapp.controller.subject.SubjectListAdapter;
import com.universalapp.sankalp.learningapp.customLoader.LoaderDialog;
import com.universalapp.sankalp.learningapp.model.chapter.ChapterResponse;
import com.universalapp.sankalp.learningapp.model.subject.SubjectResponse;
import com.universalapp.sankalp.learningapp.model.user.UserDetails;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.CustomDialog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChapterActivity extends AppCompatActivity {

    @BindView(R.id.text_title)
    TextView textViewChapterName;
    @BindView(R.id.recycler_chapter_list)
    RecyclerView recyclerViewChapter;

    @BindView(R.id.layout_quiz)
    LinearLayout linearLayoutQuiz;
    RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter);

        ButterKnife.bind(this);

        layoutManager = new LinearLayoutManager(this);
        recyclerViewChapter.setLayoutManager(layoutManager);

        linearLayoutQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Constants.SELECTED_TEST_NAME = Constants.SELECTED_TEST_SUBJECT + " - Test";
                Intent intent = new Intent(ChapterActivity.this, TestInstructionActivity.class);
                intent.putExtra(Constants.KEY_SUBJECT_ID, getIntent().getStringExtra(Constants.KEY_SUBJECT_ID));
                intent.putExtra(Constants.KEY_TEST_TYPE, Constants.TEST_TYPE_SUBJECT_WISE);
                startActivity(intent);

            }
        });

        textViewChapterName.setText(getIntent().getStringExtra(Constants.KEY_SUBJECT_NAME));

        getChapter(getIntent().getStringExtra(Constants.KEY_SUBJECT_ID));
    }

    private void getChapter(String subjectId){
        LoaderDialog dialog = new LoaderDialog(ChapterActivity.this);
        dialog.showProgress();


        Call<ChapterResponse> request = RestClient.getInstance(this).getChapter(subjectId, Constants.USER_DETAILS.getMediumId(), Constants.USER_DETAILS.getStandardId());


        request.enqueue(new Callback<ChapterResponse>() {
            @Override
            public void onResponse(Call<ChapterResponse> call, Response<ChapterResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(LoginActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){

                    ChapterListAdapter adapter = new ChapterListAdapter(ChapterActivity.this, response.body().getChapter());
                    recyclerViewChapter.setAdapter(adapter);

                }else{
                    CustomDialog.commonDialog(ChapterActivity.this, "Login fail", "Credential mismatch.", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<ChapterResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });
    }
}
