package com.universalapp.sankalp.learningapp.view.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.api.RestClient;
import com.universalapp.sankalp.learningapp.controller.chapter.ChapterListAdapter;
import com.universalapp.sankalp.learningapp.controller.membershipPlan.MebershipPlanListAdapter;
import com.universalapp.sankalp.learningapp.customLoader.LoaderDialog;
import com.universalapp.sankalp.learningapp.model.chapter.ChapterResponse;
import com.universalapp.sankalp.learningapp.model.membershipPack.MembershipResponse;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.CustomDialog;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MembershipPackActivity extends AppCompatActivity {


    @BindView(R.id.recycler_membership_pack)
    RecyclerView recyclerViewMembershipPack;

    RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership_pack);

        ButterKnife.bind(this);

        layoutManager = new LinearLayoutManager(this);
        recyclerViewMembershipPack.setLayoutManager(layoutManager);

        getMembershipPlan();

    }

    private void getMembershipPlan(){

        LoaderDialog dialog = new LoaderDialog(MembershipPackActivity.this);
        dialog.showProgress();


        Call<MembershipResponse> request = RestClient.getInstance(this).getMembershipPlan();


        request.enqueue(new Callback<MembershipResponse>() {
            @Override
            public void onResponse(Call<MembershipResponse> call, Response<MembershipResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(LoginActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){

                    MebershipPlanListAdapter adapter = new MebershipPlanListAdapter(MembershipPackActivity.this, response.body().getPlan());
                    recyclerViewMembershipPack.setAdapter(adapter);

                }else{
                    CustomDialog.commonDialog(MembershipPackActivity.this, "Login fail", "Credential mismatch.", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<MembershipResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });

    }
}
