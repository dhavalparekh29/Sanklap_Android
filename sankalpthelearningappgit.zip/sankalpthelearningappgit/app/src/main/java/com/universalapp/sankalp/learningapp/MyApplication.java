package com.universalapp.sankalp.learningapp;

import android.support.multidex.MultiDexApplication;

public class MyApplication extends MultiDexApplication {
}
