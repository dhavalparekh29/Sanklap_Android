package com.universalapp.sankalp.learningapp.utils;

public enum Orientation {

    AUTO, AUTO_START_WITH_LANDSCAPE, ONLY_LANDSCAPE, ONLY_PORTRAIT

}
