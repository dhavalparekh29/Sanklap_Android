package com.universalapp.sankalp.learningapp.customYoutubePlayer;

/**
 * Created by TheFinestArtist on 2/16/15.
 */
public enum Orientation {
    AUTO, AUTO_START_WITH_LANDSCAPE, ONLY_LANDSCAPE, ONLY_PORTRAIT
}
