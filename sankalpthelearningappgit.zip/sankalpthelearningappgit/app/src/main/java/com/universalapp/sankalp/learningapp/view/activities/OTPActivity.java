package com.universalapp.sankalp.learningapp.view.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.core.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.api.RestClient;
import com.universalapp.sankalp.learningapp.customLoader.LoaderDialog;
import com.universalapp.sankalp.learningapp.model.BasicResponse;
import com.universalapp.sankalp.learningapp.utils.AppPrefs;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.CustomDialog;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OTPActivity extends AppCompatActivity {

    @BindView(R.id.edit_otp_1)
    EditText editTextOTP1;
    @BindView(R.id.edit_otp_2)
    EditText editTextOTP2;
    @BindView(R.id.edit_otp_3)
    EditText editTextOTP3;
    @BindView(R.id.edit_otp_4)
    EditText editTextOTP4;
    @BindView(R.id.edit_otp_5)
    EditText editTextOTP5;
    @BindView(R.id.edit_otp_6)
    EditText editTextOTP6;
    @BindView(R.id.button_verify_otp)
    Button buttonVerifyOTP;

    String otp;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        ButterKnife.bind(this);
        buttonVerifyOTP.setOnClickListener(clickListener);

        genrateOTP();
    }

    private void genrateOTP(){
        otp = editTextOTP1.getText().toString()
                +editTextOTP2.getText().toString()
                +editTextOTP3.getText().toString()
                +editTextOTP4.getText().toString()
                +editTextOTP5.getText().toString()
                +editTextOTP6.getText().toString();
    }

    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent;
            switch (view.getId()){
                case R.id.button_verify_otp:

                    if(editTextOTP1.getText().toString().equalsIgnoreCase("")
                            || editTextOTP2.getText().toString().equalsIgnoreCase("")
                            || editTextOTP3.getText().toString().equalsIgnoreCase("")
                            || editTextOTP4.getText().toString().equalsIgnoreCase("")
                            || editTextOTP5.getText().toString().equalsIgnoreCase("")
                            || editTextOTP6.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(OTPActivity.this, "Please enter valid OTP", Toast.LENGTH_SHORT).show();
                    }else{
                        verifyOTP();
                    }
                    intent = new Intent(OTPActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish();

                    break;
            }
        }
    };

    private void verifyOTP(){
        LoaderDialog dialog = new LoaderDialog(OTPActivity.this);
        dialog.showProgress();

        Map<String, String> params = new HashMap<>();
        params.put("user_id", Constants.USER_DETAILS.getUserId());
        params.put("otp",otp);
        Call<BasicResponse> request = RestClient.getInstance(this).verifyOTP(params);

        request.enqueue(new Callback<BasicResponse>() {
            @Override
            public void onResponse(Call<BasicResponse> call, Response<BasicResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(LoginActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){
                    AppPrefs.getInstance(OTPActivity.this).setIsLogin(true);
                    Toast.makeText(OTPActivity.this, response.body().getMsg(), Toast.LENGTH_SHORT).show();

                }else{
                    CustomDialog.commonDialog(OTPActivity.this, response.body().getMsg(), "Credential mismatch.", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<BasicResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });
    }
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                final String message = intent.getStringExtra("message");


            }
        }
    };
    @Override
    public void onResume() {
        LocalBroadcastManager.getInstance(this).
                registerReceiver(receiver, new IntentFilter("otp"));
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }
}
