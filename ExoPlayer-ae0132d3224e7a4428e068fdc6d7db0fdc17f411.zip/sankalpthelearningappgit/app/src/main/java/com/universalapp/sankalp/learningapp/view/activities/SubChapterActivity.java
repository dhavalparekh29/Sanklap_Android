package com.universalapp.sankalp.learningapp.view.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.utils.Constants;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SubChapterActivity extends AppCompatActivity {


    @BindView(R.id.text_title)
    TextView textViewChapterName;
    @BindView(R.id.layout_video)
    LinearLayout linearLayoutVideo;
    @BindView(R.id.layout_quiz)
    LinearLayout linearLayoutQuiz;

    String chapterId, subjectId, chapterName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_chapter);
        ButterKnife.bind(this);

        chapterId = getIntent().getStringExtra(Constants.KEY_CHAPTER_ID);
        subjectId = getIntent().getStringExtra(Constants.KEY_SUBJECT_ID);
        chapterName = getIntent().getStringExtra(Constants.KEY_CHAPTER_NAME);
        textViewChapterName.setText(chapterName);
        linearLayoutVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SubChapterActivity.this, VideoListActivity.class);
                intent.putExtra(Constants.KEY_CHAPTER_ID, chapterId);
                intent.putExtra(Constants.KEY_SUBJECT_ID, subjectId);
                intent.putExtra(Constants.KEY_CHAPTER_NAME, chapterName);
                startActivity(intent);
            }
        });

        linearLayoutQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Constants.SELECTED_TEST_NAME = chapterName+" - Test";

                Intent intent = new Intent(SubChapterActivity.this, TestInstructionActivity.class);
                intent.putExtra(Constants.KEY_CHAPTER_ID, chapterId);
                intent.putExtra(Constants.KEY_SUBJECT_ID, subjectId);
                intent.putExtra(Constants.KEY_CHAPTER_NAME, chapterName);
                intent.putExtra(Constants.KEY_TEST_TYPE, Constants.TEST_TYPE_CHAPTER_WISE);
                startActivity(intent);
            }
        });
    }
}
