package com.universalapp.sankalp.learningapp.view.activities;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.api.RestClient;
import com.universalapp.sankalp.learningapp.controller.test.TestViewPagerAdapter;
import com.universalapp.sankalp.learningapp.customLoader.LoaderDialog;
import com.universalapp.sankalp.learningapp.model.BasicResponse;
import com.universalapp.sankalp.learningapp.model.quiz.QuestionDetails;
import com.universalapp.sankalp.learningapp.model.quiz.TestResponse;
import com.universalapp.sankalp.learningapp.model.quiz.submitQuiz.SubmitQuizRequest;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.CustomDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuizActivity extends AppCompatActivity {

    @BindView(R.id.text_number_of_question)
    TextView textViewNoOfQuestion;
    @BindView(R.id.text_timer)
    TextView textViewTimer;
    @BindView(R.id.viewpager_test)
    ViewPager viewPagerTest;
    @BindView(R.id.image_previous)
    ImageView imageViewPrevious;
    @BindView(R.id.image_next)
    ImageView imageViewNext;
    @BindView(R.id.button_submit)
    Button buttonSubmit;

    TestViewPagerAdapter adapter;
    List<QuestionDetails> arrayListQuestion = new ArrayList<>();

    TestResponse testResponse;
    boolean isFirstTime = true;
    Handler handler;
    Runnable runnableCode;
    Timer timer ;

    SubmitQuizRequest submitQuizRequest = new SubmitQuizRequest();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        ButterKnife.bind(this);
        /*getQuizQuestions(getIntent().getStringExtra(Constants.KEY_SUBJECT_ID),
                getIntent().getStringExtra(Constants.KEY_CHAPTER_ID));*/

        testResponse = new Gson().fromJson(getIntent().getStringExtra(Constants.KEY_TEST_RESPONSE), TestResponse.class);



        textViewNoOfQuestion.setText(testResponse.getQuestions().size()+"");
        arrayListQuestion = testResponse.getQuestions();
        adapter = new TestViewPagerAdapter(getSupportFragmentManager(), arrayListQuestion, this);
        adapter.notifyDataSetChanged();
        viewPagerTest.setAdapter(adapter);
        textViewNoOfQuestion.setText((1)+"/"+arrayListQuestion.size());

        viewPagerTest.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {

                textViewNoOfQuestion.setText((i+1)+"/"+arrayListQuestion.size());
                if((i + 1) == testResponse.getQuestions().size()){
                    imageViewNext.setVisibility(View.GONE);
                }

            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

        imageViewNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPagerTest.setCurrentItem(viewPagerTest.getCurrentItem()+1);
            }
        });

        imageViewPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPagerTest.setCurrentItem(viewPagerTest.getCurrentItem()-1);
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitTest(Constants.SUBMIT_QUIZ_REQUEST);
            }
        });


        runThread("1");


    }
    public void nextQuestion(int position){
        /*int currentItem = viewPagerTest.getCurrentItem() + 1;

        viewPagerTest.setCurrentItem(currentItem);*/
        runThread("2");
        if((position + 1) == testResponse.getQuestions().size()){
            submitTest(Constants.SUBMIT_QUIZ_REQUEST);
        }
    }
    private void runThread(String thread){

        if(handler != null){
            handler.removeCallbacks(runnableCode);
        }
        handler = new Handler();
// Define the code block to be executed


         runnableCode = new Runnable() {

            @Override
            public void run() {
                if(isFirstTime){

                }else{
                    int currentItem = viewPagerTest.getCurrentItem() + 1;

                    viewPagerTest.setCurrentItem(currentItem);
                }

                if(timer != null){

                    timer.cancel();
                    timer = null;
                }
                timer = new Timer();


                timer.schedule(new TimerTask() {

                    long seconds = testResponse.getTimePerQuestion();
                    @Override
                    public void run() {

                        seconds--;
                        runOnUiThread(new Runnable(){
                            public void run() {
                                textViewTimer.setText(seconds + " second");
                            }
                        });
                        System.out.println("Thread seconds- " + thread + " - "+seconds);
                    }

                },0,1000);

                isFirstTime = false;

                System.out.println("Thread - " + thread);
                handler.postDelayed(this, (testResponse.getTimePerQuestion()*1000));
            }
        };
// Start the initial runnable task by posting through the handler
        handler.post(runnableCode);

    }
    private void submitTest(SubmitQuizRequest submitQuizRequest){
        LoaderDialog dialog = new LoaderDialog(QuizActivity.this,"Submitting test please wait");
        dialog.showProgress();


        Call<BasicResponse> request = RestClient.getInstance(this).submitQuiz(submitQuizRequest);


        request.enqueue(new Callback<BasicResponse>() {
            @Override
            public void onResponse(Call<BasicResponse> call, Response<BasicResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(LoginActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){

                    Toast.makeText(QuizActivity.this, "Test submitted successfully", Toast.LENGTH_SHORT).show();
                    finish();

                }else{
                    CustomDialog.commonDialog(QuizActivity.this, getResources().getString(R.string.app_name), "Something went wrong please try again or contact support", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<BasicResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });
    }
}
