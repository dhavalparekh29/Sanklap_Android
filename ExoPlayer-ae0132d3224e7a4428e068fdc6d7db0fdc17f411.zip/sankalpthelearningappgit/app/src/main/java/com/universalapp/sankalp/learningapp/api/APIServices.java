package com.universalapp.sankalp.learningapp.api;

import com.google.gson.JsonObject;
import com.universalapp.sankalp.learningapp.model.BasicResponse;
import com.universalapp.sankalp.learningapp.model.chapter.ChapterResponse;
import com.universalapp.sankalp.learningapp.model.login.LoginResponse;
import com.universalapp.sankalp.learningapp.model.medium.MediumResponse;
import com.universalapp.sankalp.learningapp.model.membershipPack.MembershipResponse;
import com.universalapp.sankalp.learningapp.model.quiz.TestResponse;
import com.universalapp.sankalp.learningapp.model.quiz.submitQuiz.SubmitQuizRequest;
import com.universalapp.sankalp.learningapp.model.signup.SignupResponse;
import com.universalapp.sankalp.learningapp.model.standard.StandardResponse;
import com.universalapp.sankalp.learningapp.model.subject.SubjectResponse;
import com.universalapp.sankalp.learningapp.model.testReport.ChapterWiseReport;
import com.universalapp.sankalp.learningapp.model.testReport.GeneralWiseReport;
import com.universalapp.sankalp.learningapp.model.testReport.SubjectWiseReport;
import com.universalapp.sankalp.learningapp.model.video.VideoResponse;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by user on 2/7/2018.
 */

public interface APIServices {

    // Login
    @FormUrlEncoded
    @POST(Config.LOGIN_URL)
    Call<LoginResponse> login(@FieldMap Map<String, String> params);

    // Update profile
    @FormUrlEncoded
    @POST(Config.UPDATE_PROFILE_URL)
    Call<BasicResponse> updateProfile(@FieldMap Map<String, String> params);

    // Login
    @FormUrlEncoded
    @POST(Config.SIGNUP_URL)
    Call<SignupResponse> signup(@FieldMap Map<String, String> params);


    // get standard list
    @FormUrlEncoded
    @POST(Config.STANDARD_URL)
    Call<StandardResponse> getStandardList(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(Config.VALIDATE_OTP)
    Call<BasicResponse> verifyOTP(@FieldMap Map<String, String> params);


    // get medium list
    @GET(Config.MEDIUM_URL)
    Call<MediumResponse> getMediumList(@Query("standard_id") String param);

    // get subject list
    @GET(Config.SUBJECT_URL)
    Call<SubjectResponse> getSubject(@Query("user_id") String param);

    // get chapter list
    @GET(Config.GET_MEMBERSHIP_PLAN)
    Call<MembershipResponse> getMembershipPlan();

    // get chapter list
    @GET(Config.CHAPTER_URL)
    Call<ChapterResponse> getChapter(@Query("subject_id") String param_subject_id
            , @Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id);

    // get video list
    @GET(Config.VIDEO_URL)
    Call<VideoResponse> getVideo(@Query("subject_id") String param_subject_id
            , @Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id
            , @Query("chapter_id") String param_chapter_id);

    // get quiz questions list
    @GET(Config.QUIZ_CHAPTER_QUESTIONS_URL)
    Call<TestResponse> getChapterQuizQuestions(@Query("subject_id") String param_subject_id
            , @Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id
            , @Query("chapter_id") String param_chapter_id);

    // get quiz questions list subject
    @GET(Config.QUIZ_SUBJECT_QUESTIONS_URL)
    Call<TestResponse> getSubjectQuizQuestions(@Query("subject_id") String param_subject_id
            , @Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id);

    // get quiz questions list overall
    @GET(Config.QUIZ_GENERAL_QUESTIONS_URL)
    Call<TestResponse> getGenralQuizQuestions(@Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })
    @POST(Config.SUBMIT_QUIZ)
    Call<BasicResponse> submitQuiz(@Body SubmitQuizRequest submitQuizRequest);



    // get general test report
    @GET(Config.TEST_REPORT_GENERAL)
    Call<List<GeneralWiseReport>> getGeneralTestReport(@Query("user_id") String param_user_id
            , @Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id);

    // get subject test report
    @GET(Config.TEST_REPORT_SUBJECT)
    Call<List<SubjectWiseReport>> getSubjectTestReport(@Query("user_id") String param_user_id
            , @Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id);

    // get chapter test report
    @GET(Config.TEST_REPORT_CHAPTER)
    Call<List<ChapterWiseReport>> getChapterTestReport(@Query("user_id") String param_user_id
            , @Query("medium_id") String param_medium_id
            , @Query("standard_id") String param_standard_id);
}