package com.universalapp.sankalp.learningapp.view.activities;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.api.RestClient;
import com.universalapp.sankalp.learningapp.controller.subject.SubjectListAdapter;
import com.universalapp.sankalp.learningapp.customLoader.LoaderDialog;
import com.universalapp.sankalp.learningapp.model.medium.MediumDetails;
import com.universalapp.sankalp.learningapp.model.medium.MediumResponse;
import com.universalapp.sankalp.learningapp.model.standard.StandardResponse;
import com.universalapp.sankalp.learningapp.model.subject.SubjectResponse;
import com.universalapp.sankalp.learningapp.utils.AppPrefs;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.CustomDialog;
import com.universalapp.sankalp.learningapp.utils.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {


    @BindView(R.id.image_menu)
    ImageView imageViewMenu;

    @BindView(R.id.text_user_name)
    TextView textViewUserName;
    @BindView(R.id.text_nav_user_name)
    TextView textViewNavigationUserName;
    @BindView(R.id.text_user_standard)
    TextView textViewNavigationUserStandard;
    @BindView(R.id.text_app_version)
    TextView textViewAppVersion;

    @BindView(R.id.recycler_subject_list)
    RecyclerView recyclerViewSubjectList;

    @BindView(R.id.layout_logout)
    LinearLayout linearLayoutLogout;
    @BindView(R.id.layout_profile)
    LinearLayout linearLayoutProfile;
    @BindView(R.id.layout_quiz)
    LinearLayout linearLayoutQuiz;
    @BindView(R.id.layout_test_report)
    LinearLayout linearLayoutTestReport;
    @BindView(R.id.layout_membership)
    LinearLayout linearLayoutMembership;

    DrawerLayout drawer;
    RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ButterKnife.bind(this);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        layoutManager = new LinearLayoutManager(this);
        recyclerViewSubjectList.setLayoutManager(layoutManager);

        getSubjectList();
        textViewUserName.setText("Welcome "+Constants.USER_DETAILS.getName());
        textViewNavigationUserName.setText(Constants.USER_DETAILS.getName());
        textViewNavigationUserStandard.setText(Constants.USER_DETAILS.getStandardId());
        textViewAppVersion.setText("v"+Utils.getAppVersionName()+"("+Utils.getAppVersionCode()+")");

        imageViewMenu.setOnClickListener(clickListener);
        linearLayoutLogout.setOnClickListener(clickListener);
        linearLayoutProfile.setOnClickListener(clickListener);
        linearLayoutQuiz.setOnClickListener(clickListener);
        linearLayoutTestReport.setOnClickListener(clickListener);
        linearLayoutMembership.setOnClickListener(clickListener);
    }

    private void getSubjectList(){
        LoaderDialog dialog = new LoaderDialog(HomeActivity.this);
        dialog.showProgress();

        String params = Constants.USER_DETAILS.getUserId();
        Call<SubjectResponse> request = RestClient.getInstance(this).getSubject(params);

        request.enqueue(new Callback<SubjectResponse>() {
            @Override
            public void onResponse(Call<SubjectResponse> call, Response<SubjectResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(LoginActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){

                    SubjectListAdapter adapter = new SubjectListAdapter(HomeActivity.this, response.body().getSubject());
                    recyclerViewSubjectList.setAdapter(adapter);

                }else{
                    CustomDialog.commonDialog(HomeActivity.this, "Login fail", "Credential mismatch.", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<SubjectResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });
    }

    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            Intent intent;
            switch (view.getId()){
                case R.id.image_menu:

                    if(drawer.isDrawerOpen(GravityCompat.START)){
                        drawer.closeDrawer(Gravity.END);
                    }else{
                        drawer.openDrawer(Gravity.START);
                    }
                    break;

                case R.id.layout_logout:

                    AppPrefs.getInstance(HomeActivity.this).setIsLogin(false);
                    AppPrefs.getInstance(HomeActivity.this).setLoginUserDetails("");

                    intent = new Intent(HomeActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();

                    break;

                case R.id.layout_membership:

                    intent = new Intent(HomeActivity.this, MembershipPackActivity.class);
                    startActivity(intent);

                    break;

                case R.id.layout_profile:

                    intent = new Intent(HomeActivity.this, EditProfileActivity.class);
                    startActivity(intent);

                    break;

                case R.id.layout_quiz:

                    Constants.SELECTED_TEST_SUBJECT = "All subject test";
                    Constants.SELECTED_TEST_NAME = "General test";

                    intent = new Intent(HomeActivity.this, TestInstructionActivity.class);
                    intent.putExtra(Constants.KEY_TEST_TYPE, Constants.TEST_TYPE_GENERAL_WISE);
                    startActivity(intent);

                    break;


                case R.id.layout_test_report:

                    intent = new Intent(HomeActivity.this, TestReportActivity.class);
                    startActivity(intent);

                    break;
            }
        }
    };
}
