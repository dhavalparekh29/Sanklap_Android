package com.universalapp.sankalp.learningapp.view.activities;


import android.content.Intent;
import android.support.annotation.NonNull;

import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.utils.YouTubePlayerUtils;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.customYoutubePlayer.CustomPlayerUiController;
import com.universalapp.sankalp.learningapp.customYoutubePlayer.YouTubePlayerActivity;
import com.universalapp.sankalp.learningapp.utils.Constants;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class VideoPlayerActivity extends AppCompatActivity {

    @BindView(R.id.player_video)
    YouTubePlayerView youTubePlayerViewVideo;
    /*@BindView(R.id.seekbar_video)
    SeekBar seekBarVideo;*/
    YouTubePlayer youTubePlayer;
    private static final int RECOVERY_DIALOG_REQUEST = 1;

    String videoId ="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        ButterKnife.bind(this);
        videoId = getIntent().getStringExtra(Constants.KEY_YOUTUBE_VIDEO_ID);

        View customPlayerUi = youTubePlayerViewVideo.inflateCustomPlayerUi(R.layout.custom_player_ui);
        getLifecycle().addObserver(youTubePlayerViewVideo);

        youTubePlayerViewVideo.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                CustomPlayerUiController customPlayerUiController = new CustomPlayerUiController(VideoPlayerActivity.this, customPlayerUi, youTubePlayer, youTubePlayerViewVideo);
                youTubePlayer.addListener(customPlayerUiController);
                youTubePlayerViewVideo.addFullScreenListener(customPlayerUiController);

                YouTubePlayerUtils.loadOrCueVideo(
                        youTubePlayer, getLifecycle(),
                        videoId,0f
                );
            }
        });

    }


}
