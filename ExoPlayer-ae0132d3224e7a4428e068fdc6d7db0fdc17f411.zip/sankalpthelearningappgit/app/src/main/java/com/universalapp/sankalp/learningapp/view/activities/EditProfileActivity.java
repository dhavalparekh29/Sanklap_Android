package com.universalapp.sankalp.learningapp.view.activities;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.api.RestClient;
import com.universalapp.sankalp.learningapp.customLoader.LoaderDialog;
import com.universalapp.sankalp.learningapp.model.BasicResponse;
import com.universalapp.sankalp.learningapp.model.login.LoginResponse;
import com.universalapp.sankalp.learningapp.model.login.LoginUser;
import com.universalapp.sankalp.learningapp.utils.AppPrefs;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.CustomDialog;
import com.universalapp.sankalp.learningapp.utils.ImageUtils;
import com.universalapp.sankalp.learningapp.utils.Utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION;
import static android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION;

public class EditProfileActivity extends AppCompatActivity {


    @BindView(R.id.text_user_name)
    TextView textViewUserName;
    @BindView(R.id.text_user_number)
    TextView textViewUserNumber;
    @BindView(R.id.text_user_email)
    TextView textViewUserEmail;
    @BindView(R.id.text_user_location)
    TextView textViewUserLocation;
    @BindView(R.id.image_edit_details)
    ImageView imageViewEditDetails;
    @BindView(R.id.image_update_profile_picture)
    ImageView imageViewUpdateprofilePicture;

    LoginUser loginUser;

    private int REQUEST_CAMERA = 0, SELECT_FILE = 1, CROP_PHOTO = 3;
    private String userChoosenTask;
    File captureMediaFile;
    Uri cameraPhotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        ButterKnife.bind(this);

        loginUser = Constants.USER_DETAILS;

        textViewUserName.setText(loginUser.getName());
        textViewUserEmail.setText(loginUser.getEmail());
        textViewUserLocation.setText(loginUser.getLocation());
        textViewUserNumber.setText(loginUser.getMobile());

        imageViewEditDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editDetailsPopup();
            }
        });

        imageViewUpdateprofilePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });

    }

    private void editDetailsPopup(){
        final Dialog dialog = new Dialog(EditProfileActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.popup_edit_profile);

        EditText editTextEmail = dialog.findViewById(R.id.edit_email);
        Button buttonCancel = dialog.findViewById(R.id.button_cancel);
        Button buttonUpdate = dialog.findViewById(R.id.button_update);

        editTextEmail.setText(textViewUserEmail.getText().toString());

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateProfile(editTextEmail.getText().toString(), dialog);
            }
        });

        dialog.show();
    }

    private void updateProfile(String email, Dialog popupDialog){
        LoaderDialog dialog = new LoaderDialog(EditProfileActivity.this);
        dialog.showProgress();

        Map<String, String> params = new HashMap<>();
        params.put("email", email);
        params.put("user_id", Constants.USER_DETAILS.getUserId());
        params.put("location", "");
        Call<BasicResponse> request = RestClient.getInstance(this).updateProfile(params);

        request.enqueue(new Callback<BasicResponse>() {
            @Override
            public void onResponse(Call<BasicResponse> call, Response<BasicResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(EditProfileActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){

                    loginUser.setEmail(email);

                    AppPrefs.getInstance(EditProfileActivity.this).setLoginUserDetails(new Gson().toJson(loginUser));
                    Constants.USER_DETAILS = loginUser;

                    Toast.makeText(EditProfileActivity.this, response.body().getMsg(), Toast.LENGTH_SHORT).show();
                    popupDialog.dismiss();
                }else{
                    CustomDialog.commonDialog(EditProfileActivity.this, "Login fail", "Credential mismatch.", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<BasicResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });
    }
    private void updateProfilePicture(String base64){
        LoaderDialog dialog = new LoaderDialog(EditProfileActivity.this);
        dialog.showProgress();

        Map<String, String> params = new HashMap<>();
        params.put("avatar", base64);
        params.put("user_id", Constants.USER_DETAILS.getUserId());
        Call<BasicResponse> request = RestClient.getInstance(this).updateProfile(params);

        request.enqueue(new Callback<BasicResponse>() {
            @Override
            public void onResponse(Call<BasicResponse> call, Response<BasicResponse> response) {
                System.out.println("Login response " + response.body().toString());
                //Toast.makeText(EditProfileActivity.this, ""+response.body().getData().getUser().getUserName(), Toast.LENGTH_SHORT).show();
                Intent intent;
                if(response.body().getSuccess() == 1){

                    Toast.makeText(EditProfileActivity.this, response.body().getMsg(), Toast.LENGTH_SHORT).show();

                }else{
                    CustomDialog.commonDialog(EditProfileActivity.this, "Login fail", "Credential mismatch.", "Retry");
                }
                dialog.hideProgressBar();
            }

            @Override
            public void onFailure(Call<BasicResponse> call, Throwable t) {


                dialog.hideProgressBar();
            }
        });
    }
    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library",
                "Cancel" };

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(EditProfileActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (ContextCompat.checkSelfPermission(EditProfileActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                    Utils.readStoragePermission(EditProfileActivity.this);

                }else{
                    if (items[item].equals("Take Photo")) {
                        if (ContextCompat.checkSelfPermission(EditProfileActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

                            Utils.cameraPermission(EditProfileActivity.this);

                        }else {
                            userChoosenTask = "Take Photo";
                            cameraIntent();
                        }
                    } else if (items[item].equals("Choose from Library")) {
                        userChoosenTask ="Choose from Library";
                        galleryIntent();
                    } else if (items[item].equals("Cancel")) {
                        dialog.dismiss();
                    }
                }



            }
        });
        builder.show();
    }
    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        captureMediaFile = ImageUtils.getOutputMediaFile(getApplicationContext());


        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            intent.addFlags(FLAG_GRANT_READ_URI_PERMISSION | FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, captureMediaFile);
        } else {
            cameraPhotoUri = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".provider", captureMediaFile);
            intent.addFlags(FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri);
        }

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_CAMERA);
        } else {
            //new AlertDialogMessage(getApplicationContext()).showAToast(R.string.camera_unavailable);
            System.out.println("camera exception - unavailable");

        }

    }

    private void galleryIntent()
    {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, SELECT_FILE);

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /*if(data != null) {
            System.out.println("Picture intent " + data.getExtras());

            if (requestCode == REQUEST_CAMERA && resultCode == RESULT_OK) {
                onCaptureImageResult(data);
            } else if (requestCode == SELECT_FILE && resultCode == RESULT_OK) {
                onSelectFromGalleryResult(data);
            }
        }else{
        }*/

        if (requestCode == REQUEST_CAMERA && resultCode == RESULT_OK) {
            if(data!=null) {
                onCaptureImageResult(data);
            }else{
                updateProfilePicture(Utils.uriToBase64(cameraPhotoUri, EditProfileActivity.this));
            }
        } else if (requestCode == SELECT_FILE && resultCode == RESULT_OK) {
            if(data != null) {
                onSelectFromGalleryResult(data);
            }
        }
    }

    private void onCaptureImageResult(Intent data) {

        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");

        File file;
        file = new File(Environment.getExternalStorageDirectory() + File.separator + "img.jpg");
        FileOutputStream fo;
        try {
            file.createNewFile();
            fo = new FileOutputStream(file);
            fo.write(Utils.bitmapToByteArray(thumbnail));
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        updateProfilePicture(Utils.uriToBase64(Uri.fromFile(file), EditProfileActivity.this));
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        if (data != null) {
            try {
                updateProfilePicture(Utils.uriToBase64(data.getData(), EditProfileActivity.this));

                /*CropImage.activity(data.getData())
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .start(this);*/

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        //imageViewUserProfile.setImageBitmap(bm);
    }
}
