package com.universalapp.sankalp.learningapp.controller.selection;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.model.subject.SubjectDetails;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.view.activities.ChapterActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SubjectListSelectorAdapter extends RecyclerView.Adapter<SubjectListSelectorAdapter.MyViewHolder> {

    List<SubjectDetails> arrayListSubject = new ArrayList<>();
    Activity activity;
    int numberOfSelection;
    int totalSelection = 0 ;

    public SubjectListSelectorAdapter (Activity activity, List<SubjectDetails> arrayListSubject, int numberOfSelection){
        this.activity = activity;
        this.arrayListSubject = arrayListSubject;
        this.numberOfSelection = numberOfSelection;
    }

    @NonNull
    @Override
    public SubjectListSelectorAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        return new SubjectListSelectorAdapter.MyViewHolder(LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_check_box, viewGroup, false));

    }

    @Override
    public void onBindViewHolder(@NonNull SubjectListSelectorAdapter.MyViewHolder viewHolder, int position) {

        //viewHolder.textViewName.setText(arrayListTimeSlot.get(i).getName());

        viewHolder.checkBoxName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(viewHolder.checkBoxName.isChecked()){
                    totalSelection = totalSelection - 1;
                    viewHolder.checkBoxName.setChecked(false);
                }else{
                    if(totalSelection < numberOfSelection) {
                        totalSelection = totalSelection + 1;
                        viewHolder.checkBoxName.setChecked(true);
                    }else {
                        Toast.makeText(activity, "Maximum you can select "+numberOfSelection +" subject", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        //return arrayListTimeSlot.size();
        return arrayListSubject.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{



        @BindView(R.id.checkbox_name)
        CheckBox checkBoxName;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            ButterKnife.bind(this,itemView);

        }
    }

    public  void updateList(List<SubjectDetails> arrayListSubject){
        this.arrayListSubject = arrayListSubject;
        notifyDataSetChanged();
    }
}