package com.universalapp.sankalp.learningapp.model.signup;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.universalapp.sankalp.learningapp.model.user.UserDetails;

public class SignupResponse {

    @SerializedName("success")
    @Expose
    private Integer success;
    @SerializedName("user")
    @Expose
    private UserDetails user;
    @SerializedName("msg")
    @Expose
    private String msg;

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public UserDetails getUser() {
        return user;
    }

    public void setUser(UserDetails user) {
        this.user = user;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
