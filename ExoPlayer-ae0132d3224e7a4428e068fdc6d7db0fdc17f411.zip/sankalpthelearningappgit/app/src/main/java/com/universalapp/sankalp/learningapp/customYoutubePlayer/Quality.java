package com.universalapp.sankalp.learningapp.customYoutubePlayer;

/**
 * Created by TheFinestArtist on 6/27/15.
 */
public enum Quality {
    FIRST, SECOND, THIRD, FOURTH, MAXIMUM, STANDARD_DEFINITION, MEDIUM, HIGH, DEFAULT
}
