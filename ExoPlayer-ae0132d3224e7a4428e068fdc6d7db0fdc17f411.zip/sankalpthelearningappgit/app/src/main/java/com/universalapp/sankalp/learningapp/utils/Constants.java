package com.universalapp.sankalp.learningapp.utils;

import com.universalapp.sankalp.learningapp.model.login.LoginUser;
import com.universalapp.sankalp.learningapp.model.quiz.submitQuiz.SubmitQuizRequest;
import com.universalapp.sankalp.learningapp.model.user.UserDetails;

public class Constants {

    public static String YOUTUBE_API = "AIzaSyDjJoa9QagTqWqgP63ixftZH7oFJbG6Z04";
    public static LoginUser USER_DETAILS = new LoginUser();
    public static String KEY_SUBJECT_ID = "KEY_SUBJECT_ID";
    public static String KEY_TEST_TYPE = "KEY_TEST_TYPE";
    public static String KEY_SUBJECT_NAME = "KEY_SUBJECT_NAME";
    public static String KEY_TEST_NAME = "KEY_TEST_NAME";
    public static String KEY_TEST_RESPONSE = "KEY_TEST_RESPONSE";
    public static String KEY_CHAPTER_ID = "KEY_CHAPTER_ID";
    public static String KEY_CHAPTER_NAME = "KEY_CHAPTER_NAME";
    public static String KEY_YOUTUBE_VIDEO_ID = "KEY_YOUTUBE_VIDEO_ID";
    public static String SELECTED_TEST_SUBJECT = "";
    public static String SELECTED_TEST_NAME = "";

    public static final String TEST_TYPE_CHAPTER_WISE = "c";
    public static final String TEST_TYPE_SUBJECT_WISE = "s";
    public static final String TEST_TYPE_GENERAL_WISE = "g";

    public static SubmitQuizRequest SUBMIT_QUIZ_REQUEST = new SubmitQuizRequest();

    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 2;
    public static final int MY_CAMERA_PERMISSION = 4;
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 3;
}
