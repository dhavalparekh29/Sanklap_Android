package com.universalapp.sankalp.learningapp.view.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.gson.Gson;
import com.universalapp.sankalp.learningapp.R;
import com.universalapp.sankalp.learningapp.model.login.LoginUser;
import com.universalapp.sankalp.learningapp.model.user.UserDetails;
import com.universalapp.sankalp.learningapp.utils.AppPrefs;
import com.universalapp.sankalp.learningapp.utils.Constants;
import com.universalapp.sankalp.learningapp.utils.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {


    @BindView(R.id.text_app_version)
    TextView textViewAppVersion;

    private static final int TIME_OUT = 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, 101);
        }else {
            textViewAppVersion.setText("v" + Utils.getAppVersionName() + "(" + Utils.getAppVersionCode() + ")");

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    Intent intent;

                    if (AppPrefs.getInstance(MainActivity.this).getIsLogin() == true) {
                        Constants.USER_DETAILS = new Gson().fromJson(AppPrefs.getInstance(MainActivity.this).getLoginUserDetails(), LoginUser.class);
                        intent = new Intent(MainActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        intent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }

                }
            }, TIME_OUT);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, 101);
        }else {
            textViewAppVersion.setText("v" + Utils.getAppVersionName() + "(" + Utils.getAppVersionCode() + ")");

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    Intent intent;

                    if (AppPrefs.getInstance(MainActivity.this).getIsLogin() == true) {
                        Constants.USER_DETAILS = new Gson().fromJson(AppPrefs.getInstance(MainActivity.this).getLoginUserDetails(), LoginUser.class);
                        intent = new Intent(MainActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        intent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }

                }
            }, TIME_OUT);
        }

    }
}
